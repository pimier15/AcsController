﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDctXYZStage
{
    public interface IXStageOrder
    {
        #region Connect
        bool XStageConnect(string port);
        bool XStageRelease();

        #endregion
        string XMovePosSetCommand { get; set; }
        string XMoveSettedPosCommand { get; set; }
        string XOriginCommand { get; set; }
        string XStatusCommand { get; set; }

        void XMoveAbsPos(int pos);
        void XWait2Arrive(int targetPos);
        void XWait2ArriveEpsilon(int targetPos, double epsilon);
        void XOrigin();
        void XSetXSpeed(int speed, int acc);
        void XForceStop();
        string XStatus();
    }
}
