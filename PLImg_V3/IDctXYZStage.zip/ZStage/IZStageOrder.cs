﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IDctXYZStage
{
    public interface IZStageOrder
    {
        #region Connect
        bool ZStageConnect(string port);
        bool ZStageRelease();

        #endregion
        string ZMovePosSetCommand { get; set; }
        string ZMoveSettedPosCommand { get; set; }
        string ZOriginCommand { get; set; }
        string ZStatusCommand { get; set; }

        void ZMoveAbsPos(int pos);
        void ZWait2Arrive(int targetPos);
        void ZWait2ArriveEpsilon(int targetPos, double epsilon);
        void ZOrigin();
        void ZSetXSpeed(int speed, int acc);
        void ZForceStop();
        string ZStatus();
    }
}
